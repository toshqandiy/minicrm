from django.contrib import admin
from .models import Userprofile

admin.site.register(Userprofile)